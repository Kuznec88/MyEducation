public class Movements {

    public Movements(String pathMovementsCsv) {
    }

    public double getExpenseSum() {
        return 0.0;
    }

    public double getIncomeSum() {
        return 0.0;
    }
}
