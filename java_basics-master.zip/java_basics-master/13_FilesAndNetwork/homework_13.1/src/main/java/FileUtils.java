public class FileUtils {

    public static long calculateFolderSize(String path) {
        return 0;
    }
}
