import com.skillbox.airport.Airport;
import com.skillbox.airport.Flight;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) {


    }

    public static List<Flight> findPlanesLeavingInTheNextTwoHours(Airport airport) {
        //TODO Метод должден вернуть список рейсов вылетающих в ближайшие два часа.
        return Collections.emptyList();
    }

}