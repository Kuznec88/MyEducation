import java.time.LocalDate;

public class Main {

  public static void main(String[] args) {

  }

  private static String getPeriodFromBirthday(LocalDate birthday) {
    return "";
  }

}
