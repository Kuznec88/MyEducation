public enum CatColor
{
    // задание 3.4
    WHITE,
    BLACK,
    GINGER,
    TORTOISESHELL,
}
