public interface Employee
{
    double getMonthSalary();
    void setCompanyMoney();
}