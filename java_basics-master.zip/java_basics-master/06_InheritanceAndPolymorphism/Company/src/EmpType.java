public enum EmpType {
    Manager,
    Operator,
    TopManager
}
