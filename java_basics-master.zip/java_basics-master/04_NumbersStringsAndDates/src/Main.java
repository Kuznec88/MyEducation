public class Main {
    public static void main(String[] args) {
        int truck;
        int container;
        int box;
    }

}
