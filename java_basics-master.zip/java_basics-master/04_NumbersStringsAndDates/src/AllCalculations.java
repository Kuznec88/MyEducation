public class AllCalculations {
}
