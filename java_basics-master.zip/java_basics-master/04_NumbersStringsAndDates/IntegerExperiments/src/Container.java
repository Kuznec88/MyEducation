public class Container
{
    public int count;
}